extends CharacterBody2D

const MOVE_SPEED = 50
const FIRE_RATE = 0.3
var fire_time = 0.0

var laser = preload("res://laser.tscn")
var dead = false
var explosion = preload("res://explosion.tscn")

func _ready():
	add_to_group("player")

func _physics_process(delta):
	var move_vec = Vector2()
	if Input.is_action_pressed("move_up"):
		move_vec.y -= 5
	if Input.is_action_pressed("move_down"):
		move_vec.y += 5
	if Input.is_action_pressed("move_left"):
		move_vec.x -= 5
	if Input.is_action_pressed("move_right"):
		move_vec.x += 5
	move_and_collide(move_vec * delta * MOVE_SPEED)
	
func _process(delta):
	if Input.is_action_just_pressed("shoot"):
		shoot()

func shoot():
	if get_time() - fire_time < FIRE_RATE:
		return
	fire_time = get_time()
	var las = laser.instantiate()
	get_tree().get_root().add_child(las)
	las.global_position = $FirePoint.global_position
	
func get_time():
	return Time.get_ticks_msec() / 1000.0

func p_kill():
	var expl = explosion.instanciate()
	get_tree().get_root().add_child(expl)
	expl.global_position = global_position
	$Sprite.hide()
	dead = true
	#$CanvasLayer/RestartMessage.show()
